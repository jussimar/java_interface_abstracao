package tema2;

public abstract class Pessoa {
    protected String nome;
    protected String sobrenome;
    protected int idade;
    
    public abstract void mostrarNomeCompleto();
    public abstract void mostrarIdade();
}
