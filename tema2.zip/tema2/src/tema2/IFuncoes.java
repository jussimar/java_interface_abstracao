package tema2;

public interface IFuncoes {
    void MostrarSalario();
    void MostrarCodFuncionario();
}
